import React, { useState, useEffect, createContext, useContext } from "react";
import { Hsluv } from "hsluv";
import { AppBar, Toolbar, Button, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper, CssBaseline, Stack, ThemeProvider, createTheme} from "@mui/material";
import Grid from '@mui/material/Grid2';

// icons and logos
import lightLogo from "./enverus-logo-light.svg";  // Light mode logo
import darkLogo from "./enverus-logo-dark.svg";  // Dark mode logo
import LightModeIcon from '@mui/icons-material/LightMode';
import DarkModeIcon from '@mui/icons-material/DarkMode';

/* ------ PARAMETERS ------ */

// Min and Max lightness range
const LIGHTNESS_RANGE = { min: 9, max: 95 };
/*
    # 📌 Adjustments for Light & Dark Mode Colors

    # Saturation Adjustments
    
    # Some hues need slight saturation tweaks to achieve visual balance with the others:
        - Red, Orange: Sat = 80-90 (to control intensity).
        - Yellow: Sat = 90 (prevents it from appearing too light).
        - Green: Sat = 85-90 (prevents dullness).
        - Blue, Purple: Sat = 100 (to maintain vibrancy).

    # Hue-Adjusted Saturation
        - For Light Mode: Slightly reduce saturation to avoid overly vibrant colors.
        - For Dark Mode: Increase saturation to prevent dullness.

    |------------|------------------------------|-------------------------------|
    | Color      | Light Mode (Saturation%)     | Dark Mode (Saturation%)       |
    |------------|------------------------------|-------------------------------|
    | Red        | 80%                          | 90%                           |
    | Orange     | 85%                          | 95%                           |
    | Yellow     | 90%                          | 80% (reduce to prevent glare) |
    | Green      | 70%                          | 75%                           |
    | Cyan       | 60%                          | 80%                           |
    | Blue       | 100%                         | 85%                           |
    | Purple     | 100%                         | 95%                           |
    |------------|------------------------------|-------------------------------|

    # Lightness Adjustments
        - For Light Mode: reduce lightness slightly to maintain contrast.
        - For Dark Mode: increase the lightness of colors to compensate for the dark background.
    |------------|------------------------------|-------------------------------|
    | Color      | Light Mode (Lightness adj)   | Dark Mode (Lightness adj)     |
    |------------|------------------------------|-------------------------------|
    | Red        | -1%                          | -                             |
    | Orange     | -5%                          | -                             |
    | Yellow     | -1%                          | -                             |
    | Green      | +1%                          | +1%                           |
    | Cyan       | -1%                          | +2%                           |
    | Blue       | -                            | -                             |
    | Purple     | -                            | +2%                           |
    |------------|------------------------------|-------------------------------|

    > **Why?** Dark mode backgrounds are darker, so colors need **higher lightness** for better contrast.
*/

// Base Hue and Saturation values for light and dark modes


const LIGHT_MODE_COLOR_PARAMS = [ 
    { name: "Red", hue: 16, sat: 80, lightnessAdjustment: 0.99 },
    { name: "Orange", hue: 27, sat: 85, lightnessAdjustment: 0.95 },
    { name: "Yellow", hue: 60, sat: 90, lightnessAdjustment: 0.99 },
    { name: "Green", hue: 121, sat: 70, lightnessAdjustment: 1.01 },
    { name: "Cyan", hue: 180, sat: 60, lightnessAdjustment: 0.99 },
    { name: "Blue", hue: 245, sat: 100, lightnessAdjustment: 1.0 },
    { name: "Purple", hue: 275, sat: 100, lightnessAdjustment: 1.0 },
];

const DARK_MODE_COLOR_PARAMS = [ 
    { name: "Red", hue: 16, sat: 90, lightnessAdjustment: 1.0 },
    { name: "Orange", hue: 27, sat: 95, lightnessAdjustment: 1.0 },
    { name: "Yellow", hue: 60, sat: 80, lightnessAdjustment: 1.0 },
    { name: "Green", hue: 118, sat: 75, lightnessAdjustment: 1.02 },
    { name: "Cyan", hue: 180, sat: 85, lightnessAdjustment: 1.02 },
    { name: "Blue", hue: 245, sat: 90, lightnessAdjustment: 1.01 },
    { name: "Purple", hue: 275, sat: 95, lightnessAdjustment: 1.02 },
];
// the number of colors in each color ramp
const STEPS = 12; 

// the name of the colors in each ramp (i.e. red 0, red 10, etc)e 
const STEP_NAMES = [0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 95, 100];

// Context for toggling dark mode
const ThemeContext = createContext();

// Generates a color ramp based on the base hue and sat values passed.
const generateColorRamp = (hue, sat, lightnessAdjustment) => {
    // defines an array of evenly distributed series of lightness values, with some adjustments
    const lightnessValues = Array.from(
        { length: STEPS },
        (_, i) => Math.round(LIGHTNESS_RANGE.min + (LIGHTNESS_RANGE.max / (STEPS)) * lightnessAdjustment * i ) 
    );

    return lightnessValues.map((l) => {
        const hsluvInstance = new Hsluv();
        hsluvInstance.hsluv_h = hue;
        hsluvInstance.hsluv_s = 90 * (sat/100);  //sat;
        hsluvInstance.hsluv_l = l;
        hsluvInstance.hsluvToRgb();

        const r = Math.round(hsluvInstance.rgb_r * 255);
        const g = Math.round(hsluvInstance.rgb_g * 255);
        const b = Math.round(hsluvInstance.rgb_b * 255);
        const a = 1; // Full opacity

        const rgbaColor = "rgba(" + r + "," + g + "," + b + "," + a + ")";

        const hexColor = rgbToHex([r / 255, g / 255, b / 255]);

        return {
            step: STEP_NAMES[lightnessValues.indexOf(l)],
            hex: hexColor,
            rgba: rgbaColor, //`rgba(${r}, ${g}, ${b}, ${a})`,
            hsluv: `hsluv(${Math.round(hue)},${sat}%,${l}%)`,
        };
    });
};


// Dark Mode Theme Provider Component
const ThemeProviderComponent = ({ children }) => {
    const [darkMode, setDarkMode] = useState(true);

    const toggleTheme = () => {
        setDarkMode(!darkMode);
    };

    const theme = createTheme({
        palette: {
            mode: darkMode ? "dark" : "light",
            background: {
                default: darkMode ? "#1e1e1e" : "#ffffff", // Dark mode: dark gray, Light mode: light gray
                paper: darkMode ? "#1e1e1e" : "#ffffff",  // Table background colors
            },
            text: {
                primary: darkMode ? "#ffffff" : "#000000", // Adjust text colors
            }
        },
        components: {
            MuiTableCell: {
            styleOverrides: {
                root: {
                    fontSize: "14px", // Default font size for all table cells
                },
            },
            },
        },
    });

    return (
        <ThemeContext.Provider value={{ darkMode, toggleTheme }}>
            <ThemeProvider theme={theme}>
                <CssBaseline />
                <div style={{ backgroundColor: theme.palette.background.default, minHeight: "100vh", padding: "20px" }}>
                    {children}
                </div>
            </ThemeProvider>
        </ThemeContext.Provider>
    );
};


const ColorPaletteGenerator = () => {    
    const { darkMode, toggleTheme } = useContext(ThemeContext);

    // Select the appropriate saturation values based on theme
    const selectedParams = darkMode ? DARK_MODE_COLOR_PARAMS : LIGHT_MODE_COLOR_PARAMS;
    const logMessage = darkMode ? 'generating palette for dark mode' : 'generating palette for light mode';
    console.log(logMessage);

    const [colorRamps, setColorRamps] = useState([]);

    // Generate color ramps when component mounts or when theme changes
    useEffect(() => {
        setColorRamps(
            selectedParams.map(({ name, hue, sat, lightnessAdjustment }) => ({
                name,
                hue,
                sat,
                colorRamp: generateColorRamp(hue, sat, lightnessAdjustment),
            }))
        );
    }, [darkMode, selectedParams]); // Runs only when darkMode changes


    const [loading] = useState(false);

    // function for manually regenerating the color ramps based on the selected dark/light mode.
    // const regeneratePalette = () => {
    //     const logMessage = darkMode ? 'regenerating palette for dark mode' : 'regenerating palette for light mode';
    //     console.log(logMessage);
        
    //     setLoading(true); // Hide palette temporarily
    //     setTimeout(() => {
    //         setColorRamps(
    //             selectedParams.map(({ name, hue, sat }) => ({
    //                 name,
    //                 hue,
    //                 sat,
    //                 colorRamp: generateColorRamp(hue, sat),
    //             }))
    //         );
    //         setLoading(false); // Show palette again
    //     }, 100); // Short delay for UI effect
    // };


    return (        
        <div style={{ padding: "15px", textAlign: "left" }}>            
            <AppBar component="nav">                
                <Toolbar>
                    <img height="50px" alt="enverus logo" className="logo"  src={darkMode ? darkLogo : lightLogo} />
                    <div style={{ lineHeight: "1", height: "14px", fontSize: "22px", verticalAlign: "bottom", marginLeft: "8px" }}> HSLuv Color Palette Generator </div>
                </Toolbar>
            </AppBar>

            <Grid container spacing={2} style={{marginTop: '50px'}}>
                <Grid size={6}>
                    <Stack
                        direction="row"
                        spacing={1}
                        sx={{
                            justifyContent: "flex-start",
                            alignItems: "flex-start",
                            paddingBottom: "16px"
                        }}
                    >
                        
                        {/* <Button
                            color="primary"
                            onClick={regeneratePalette}
                            style={{
                                backgroundColor: darkMode ? "#444" : "#ddd",
                                color: darkMode ? "#fff" : "#000",
                            }}
                        >
                            Regenerate Palette
                        </Button>
                         */}
                       
                        <Button
                            onClick={toggleTheme}
                            LightModeIcon
                            style={{
                                backgroundColor: darkMode ? "#444" : "#ddd",
                                color: darkMode ? "#fff" : "#000",
                            }}
                        >
                            {darkMode ?<LightModeIcon /> :  <DarkModeIcon/> } &nbsp; Go {darkMode ? 'Light'  : "Dark"} 
                        </Button>
                    </Stack>
                </Grid>
                <Grid size={6}>
                    <Stack
                        direction="row"
                        spacing={1}
                        sx={{
                            justifyContent: "flex-end",
                            alignItems: "flex-end",
                            paddingBottom: "16px"
                        }}
                    >
                        <Button
                            onClick={() => exportAsJSON(colorRamps)}
                            style={{
                                    backgroundColor: darkMode ? "#444" : "#ddd",
                                    color: darkMode ? "#fff" : "#000",
                                }}
                        >
                            Export JSON
                        </Button>
                        <Button
                            onClick={() => exportAsCSV(colorRamps)}
                            style={{
                                    backgroundColor: darkMode ? "#444" : "#ddd",
                                    color: darkMode ? "#fff" : "#000",
                                }}
                        >
                            Export CSV
                        </Button>
                        <Button onClick={() => exportAsDesignTokens(colorRamps)} style={{
                                    backgroundColor: darkMode ? "#444" : "#ddd",
                                    color: darkMode ? "#fff" : "#000",
                                }}>
                            Export Design Tokens
                        </Button>
                    </Stack>
                </Grid>
            </Grid>
            {!loading ? ( // Hide the palette when regenerating
                <TableContainer component={Paper} sx={{ boxShadow: 0 }}>
                    <Table>
                        <TableHead>
                            <TableRow>
                                <TableCell>
                                    Color Name
                                </TableCell>
                                {Array.from({ length: STEPS }, (_, i) => (
                                    <TableCell key={i} align="center">
                                        {" "}
                                        {STEP_NAMES[i]}
                                    </TableCell>
                                ))}
                            </TableRow>
                        </TableHead>
                        <TableBody>
                            {colorRamps.map(({ name, colorRamp }) => (
                                <TableRow key={name}>
                                    <TableCell>
                                        <small>{name}</small>
                                    </TableCell>
                                    {colorRamp.map(({ hex, hsluv, rgba }, i) => (
                                        <TableCell
                                            key={i}
                                            align="center"
                                            style={{
                                                backgroundColor: hex,
                                                color: (parseInt(hsluv.match(/\d+/g)[2]) >= 50 ? "black" : "white"),
                                                padding: "10px",
                                            }}
                                            title={hsluv} // Show HSLuv value on hover
                                        >
                                            <p><pre>{hex}</pre></p>
                                            <div>
                                                <code style={{ whiteSpace: 'nowrap', fontWeight: '500' }}>{rgba}</code>
                                            </div>
                                            <div>
                                                <code style={{ whiteSpace: 'nowrap', fontWeight: '500' }}>{hsluv}</code>
                                            </div>
                                        </TableCell>
                                    ))}
                                </TableRow>
                            ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            ) : (
            <h2 style={{ marginTop: "20px" }}>Regenerating Palette...</h2> // Show regenerating message
        )}
        </div>
    );
};

// Function to create a hex color code from an rgb array of red, green, blue values.
const rgbToHex = (rgbArray) => {
    return (
        "#" +
        rgbArray
            .map((value) => {
                const hex = Math.round(value * 255).toString(16);
                return hex.length === 1 ? "0" + hex : hex;
            })
            .join("")
    );
};

// function to download an exported token file
const downloadFile = (data, filename, type) => {
    const blob = new Blob([data], { type });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};

// function to export design tokens in JSON Format
const exportAsJSON = (colorRamps) => {
    // console.log('color ramps: ' + JSON.stringify(colorRamps));
    const jsonData = JSON.stringify(colorRamps, null, 2);
    downloadFile(jsonData, "color_palette.json", "application/json");
};

// function to export design tokens in CSV Format
const exportAsCSV = (colorRamps) => {
    let csv = "Color Name," + STEP_NAMES.join(",") + "\n";

    colorRamps.forEach(({ name, colorRamp }) => {
        csv += name + "," + colorRamp.map(({ hex }) => hex).join(",") + "\n";
    });

    downloadFile(csv, "color_palette.csv", "text/csv");
};

// function to export design tokens in Design Token Community Group Format
// TODO: this needs some love as it's not currently in the proper DTCG format. 
const exportAsDesignTokens = (colorRamps) => {
    const designTokens = {
        "$schema": "https://design-tokens.github.io/community-group/format/",
        "color": {}
    };

    // TODO: this needs to handle color for both dark and light modes
    colorRamps.forEach(({ name, colorRamp }) => {
        designTokens.color[name.toLowerCase()] = {};
        colorRamp.forEach(({ hex, step }) => {
            designTokens.color[name.toLowerCase()][`${step}`] = {
                "value": hex
            };
        });
    });

    downloadFile(JSON.stringify(designTokens, null, 2), "design_tokens.json", "application/json");
};

const App = () => {
    return (
        <ThemeProviderComponent>
            <ColorPaletteGenerator />
        </ThemeProviderComponent>
    );
};

export default App;