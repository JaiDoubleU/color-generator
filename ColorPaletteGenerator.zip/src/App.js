import React from "react";
import ColorPaletteGenerator from "./ColorPaletteGenerator";
import './App.css';

function App() {
  return (
    <div className="App">
      <ColorPaletteGenerator />
    </div>
  );
}

export default App;

